<?php
// This is a simple way to read the .env file. For production,
// consider using a library like phpdotenv for better security.

$env_vars = file(__DIR__ . '/.env', FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
$api_key = '';

foreach ($env_vars as $line) {
    if (strpos($line, 'GOOGLE_MAPS_API_KEY') === 0) {
        $api_key = trim(str_replace('GOOGLE_MAPS_API_KEY=', '', $line), '"');
        break;
    }
}

// Set the content type to JSON
header('Content-Type: application/json');

// Return the key as a JSON object
echo json_encode(['apiKey' => $api_key]);
?>